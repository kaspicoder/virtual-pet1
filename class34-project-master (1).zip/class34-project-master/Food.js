class Food{
constructor(){
    this.foodStock
    this.lastFed
}

getFoodStck(){

}
updateFoodStack(){

}
deductFoodStack(){

}
display(){
    
}

}